# AIWWW — public frontend prototype

This repository folder contains only the public-facing AIWWW HTML prototype. It does **not** contain the private 6D backend, agents, databases, credentials or deployment settings.

The interface calls `/api/...` endpoints, which will not work on static hosting until a separately secured backend is deployed. Do not present it as a live matching platform.

Deployment to aiwww.nl requires separate authorization and security verification.
